import NewYearAvatarEditor from '../components/NewYearAvatarEditor'

export default function Home() {
  return (
    <main>
      <NewYearAvatarEditor />
    </main>
  )
}
